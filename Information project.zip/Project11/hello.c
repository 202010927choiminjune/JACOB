#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct student
{
    char name[64];
    char gender;
    char address[32];
    char dept[32];
    double gpa;
    int height;
    int weight;
} typedef student;

struct node
{
    student data;
    struct node* next;
};

struct node* list;

void process_create();
void process_load(char* tok2);
void process_print();
void process_insert(char* tok2, char* tok3, char* tok4, char* tok5, char* tok6, char* tok7, char* tok8);
void process_delete(char* tok2);
void process_search(char* tok2);

struct node* create_node(student data);
void insert_node(struct node** head, student data);
void delete_node(struct node** head, char* name);
struct node* search_node(struct node* head, char* name);
void print_list(struct node* head);

int main()
{
    FILE* fp = fopen("input.txt", "r+t");
    char input[512];
    char tok1[32], tok2[32], tok3[32], tok4[32], tok5[32], tok6[32], tok7[32], tok8[32], tok9[32];

    while (fgets(input, 512, fp) != NULL)
    {
        sscanf(input, "%s%s%s%s%s%s%s%s%s", tok1, tok2, tok3, tok4, tok5, tok6, tok7, tok8, tok9);
        if (strcmp(tok1, "CREATE") == 0)
        {
            process_create();
            printf(" %s done =======================================\n\n", tok1);
        }
        else if (strcmp(tok1, "LOAD") == 0)
        {
            process_load(tok2);
            printf(" %s done =======================================\n\n", tok1);
        }
        else if (strcmp(tok1, "PRINT") == 0)
        {
            process_print();
            printf(" %s done =======================================\n\n", tok1);
        }
        else if (strcmp(tok1, "INSERT") == 0)
        {
            process_insert(tok2, tok3, tok4, tok5, tok6, tok7, tok8);
            printf(" %s done =======================================\n\n", tok1);
        }
        else if (strcmp(tok1, "DELETE") == 0)
        {
            process_delete(tok2);
            printf(" %s done =======================================\n\n", tok1);
        }
        else if (strcmp(tok1, "SEARCH") == 0)
        {
            process_search(tok2);
            printf(" %s done =======================================\n\n", tok1);
        }
        else
        {
            printf("%s is not a keyword.\n", tok1);
        }
    }
}

void process_create()
{
    list = NULL;
}

void process_load(char* tok2)
{
    FILE* file = fopen(tok2, "r");
    char buffer[512];

    while (!feof(file))
    {
        student temp;
        fscanf(file, "%s %c %s %s %lf %d %d\n", temp.name, &temp.gender, temp.address, temp.dept, &temp.gpa, &temp.height, &temp.weight);
        insert_node(&list, temp);
    }
}

void process_print()
{
    print_list(list);
}

void process_insert(char* tok2, char* tok3, char* tok4, char* tok5, char* tok6, char* tok7, char* tok8)
{
    student new_data;
    strcpy(new_data.name, tok2);
    new_data.gender = *tok3;
    strcpy(new_data.address, tok4);
    strcpy(new_data.dept, tok5);
    new_data.gpa = atof(tok6);
    new_data.height = atoi(tok7);
    new_data.weight = atoi(tok8);

    insert_node(&list, new_data);
}

void process_delete(char* tok2)
{
    delete_node(&list, tok2);
}

void process_search(char* tok2)
{
    struct node* res = search_node(list, tok2);
    if (res != NULL)
    {
        printf("%s %c %s %s %lf %d %d\n", res->data.name, res->data.gender, res->data.address, res->data.dept, res->data.gpa, res->data.height, res->data.weight);
    }
    else
    {
        printf("Node not found.\n");
    }
}

struct node* create_node(student data)
{
    struct node* new_node = (struct node*)malloc(sizeof(struct node));
    new_node->data = data;
    new_node->next = NULL;
    return new_node;
}

void insert_node(struct node** head, student data)
{
    struct node* new_node = create_node(data);

    if (*head == NULL || strcmp(data.name, (*head)->data.name) < 0)
    {
        new_node->next = *head;
        *head = new_node;
        return;
    }

    struct node* current_node = *head;

    while (current_node->next != NULL && strcmp(current_node->next->data.name, data.name) < 0)
    {
        current_node = current_node->next;
    }

    new_node->next = current_node->next;
    current_node->next = new_node;
}

void delete_node(struct node** head, char* name)
{
    struct node* current_node = *head;
    struct node* previous_node = NULL;

    while (current_node != NULL && strcmp(current_node->data.name, name) != 0)
    {
        previous_node = current_node;
        current_node = current_node->next;
    }

    if (current_node != NULL)
    {
        if (current_node == *head)
        {
            *head = current_node->next;
        }
        else
        {
            previous_node->next = current_node->next;
        }
        free(current_node);
    }
}

struct node* search_node(struct node* head, char* name)
{
    while (head != NULL && strcmp(head->data.name, name) != 0)
    {
        head = head->next;
    }
    return head;
}

void print_list(struct node* head)
{
    while (head != NULL)
    {
        printf("%s %c %s %s %lf %d %d\n", head->data.name, head->data.gender, head->data.address, head->data.dept, head->data.gpa, head->data.height, head->data.weight);
        head = head->next;
    }
    printf("\n");
}